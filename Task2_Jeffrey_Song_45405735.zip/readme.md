# Mobile 

## Pixel_2_API_29

# Account

## user: medusa@gmail.com
## Password: 1234

node modules are deleted for more compression.
- Need to npm install
- npm start
- a