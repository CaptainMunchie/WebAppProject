export default{
    black: '#000',
    white: '#fff',
    // primaryColor: '#4e5c50',
    primaryColor: '#606c38',
    secondaryColor: '#824c28',
    // otherColor: '#ddcdb3',
    otherColor: '#e6ccb2',
    // otherColorLite: '#f2eadf',
    otherColorLite: '#ede0d4',
    brown: '#bc6c25',
    green: '#606c38',
}